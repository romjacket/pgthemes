Original copyright:
- Nils Bonenberger, CC-BY-NC-SA
- Florian Müller, CC-BY-NC-SA
